#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 深度表单探测：校准下拉选项与"指定设备"后的分组控件（不保存，无副作用）
================================================================================
 流程：登录 -> 打开新增任务页 -> 选产品 -> 打印固件版本选项 ->
       点"指定设备" -> 打印新出现的控件 -> 截图退出
 运行：python probe_form2.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest
from core.utils import load_yaml_config


def dump_visible_options(page, tag):
    """打印当前所有可见的下拉选项（覆盖常见下拉容器）。"""
    print(f"\n--- {tag} ---")
    seen = set()
    for sel in [".el-select-dropdown__item:visible",
                    ".ant-select-item-option:visible",
                    "[role='option']:visible",
                    ".el-cascader-node:visible",
                    "li:visible"]:
        loc = page.locator(sel)
        try:
            n = loc.count()
        except Exception:
            n = 0
        for i in range(min(n, 30)):
            try:
                txt = loc.nth(i).inner_text(timeout=500).strip()
                if txt and txt not in seen and len(txt) < 60:
                    seen.add(txt)
                    print(f"    {txt}")
            except Exception:
                pass
    if not seen:
        print("    (未捕获到选项)")


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    test = BatteryOTAStressTest(config)
    try:
        test.setup()
        test._ensure_login(run_index=0)
        test._navigate_to_ota_list(run_index=0)
        test._open_create_dialog(run_index=0)
        page = test.page
        page.wait_for_timeout(2000)

        # ---------- 1. 产品下拉：打印选项，选"智莱换电柜" ----------
        print("\n>>> 点开产品下拉")
        test._smart_click(["选择产品", "请选择产品"], "产品下拉", timeout=4000, exact=False)
        page.wait_for_timeout(1200)
        dump_visible_options(page, "产品选项列表")
        # 选择智莱换电柜
        clicked = test._click_first_visible(page.get_by_text("智莱换电柜", exact=False), 4000)
        print(f"\n选择【智莱换电柜】: {'成功' if clicked else '失败'}")
        page.wait_for_timeout(1500)
        test.screenshot("probe2_product_selected", 0)

        # ---------- 2. 固件版本下拉：打印选项（确认 bms 显示格式） ----------
        print("\n>>> 点开固件版本下拉")
        try:
            test._smart_click(["请选择固件版本", "请选择固件", "选择固件版本"], "固件版本下拉", timeout=4000, exact=False)
        except Exception as e:
            print(f"  点开固件下拉失败: {e}")
        page.wait_for_timeout(1200)
        dump_visible_options(page, "固件版本选项列表")
        page.keyboard.press("Escape")  # 关掉下拉
        page.wait_for_timeout(500)

        # ---------- 3. 点"指定设备"，看新出现的控件 ----------
        print("\n>>> 点击升级范围【指定设备】")
        test._smart_click(["指定设备"], "指定设备", timeout=4000, exact=True)
        page.wait_for_timeout(2000)
        test.screenshot("probe2_after_scope", 0)

        print("\n[指定设备后 - 全部可见 label]")
        labels = page.locator("label:visible")
        for i in range(min(labels.count(), 30)):
            try:
                txt = labels.nth(i).inner_text(timeout=500).strip()
                if txt:
                    print(f"    - {txt}")
            except Exception:
                pass

        print("\n[指定设备后 - 可见输入框 placeholder]")
        inputs = page.locator("input:visible")
        for i in range(min(inputs.count(), 30)):
            try:
                ph = inputs.nth(i).get_attribute("placeholder")
                if ph:
                    print(f"    - {ph}")
            except Exception:
                pass

        print("\n[指定设备后 - 可见下拉占位文字]")
        for sel in [".el-select__placeholder:visible", ".ant-select-selection-placeholder:visible"]:
            loc = page.locator(sel)
            for i in range(min(loc.count(), 20)):
                try:
                    txt = loc.nth(i).inner_text(timeout=500).strip()
                    if txt:
                        print(f"    - {txt}")
                except Exception:
                    pass

        test.screenshot("probe2_final", 0)
        print("\n探测完成（未保存，无副作用）")
        return 0
    except Exception as e:
        print(f"\n[探测失败] {e}")
        import traceback
        traceback.print_exc()
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
