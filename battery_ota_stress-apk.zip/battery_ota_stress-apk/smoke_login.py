#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 冒烟自测脚本：只验证"启动浏览器 + 打开OTA页 + 自动登录(含验证码识别)"
================================================================================
 不会创建任何真实升级任务！登录成功即退出。
 运行：python smoke_login.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest, _FRAMEWORK_ROOT  # 复用业务类的登录逻辑
from core.utils import load_yaml_config


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    print(f"框架根目录: {_FRAMEWORK_ROOT}")
    print("=" * 60)
    print("冒烟自测开始：目标 = 浏览器启动 -> 访问OTA列表页 -> 自动登录成功")
    print("=" * 60)

    test = BatteryOTAStressTest(config)
    try:
        # 只初始化浏览器，不进入压测循环
        test.setup()
        # 执行登录检查/自动登录
        test._ensure_login(run_index=0)
        # 最终确认：能看到"新增任务"按钮才算真的登录成功
        ok = test.page.locator("text=新增任务").count() > 0
        test.screenshot("smoke_final", 0)
        if ok:
            print("\n" + "=" * 60)
            print("[自测通过] 自动登录成功，已进入 OTA 任务列表页，能看到【新增任务】按钮")
            print("=" * 60)
            return 0
        else:
            print("\n" + "=" * 60)
            print("[自测未通过] 登录流程走完但页面上没找到【新增任务】按钮")
            print(f"当前URL: {test.page.url}")
            print("请查看 reports 目录下的日志和截图排查")
            print("=" * 60)
            return 1
    except Exception as e:
        print(f"\n[自测失败] {e}")
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
