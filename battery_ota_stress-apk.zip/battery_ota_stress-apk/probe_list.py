#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 探测脚本：分析 OTA 任务列表页 DOM 结构（无副作用，不创建任何任务）
================================================================================
 背景：端到端验证时任务创建成功，但脚本在列表里找不到任务名。
 怀疑：任务名称列被省略号截断，完整名不在 DOM 文本里。
 目的：搞清楚
   1. 完整任务名是否存在于页面 HTML 中
   2. 名称列单元格的真实结构（文本/截断/title 属性）
   3. 表格行（tr）结构、操作列【启动】按钮的标签写法
 运行：python probe_list.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest  # 复用业务类（登录/导航逻辑）
from core.utils import load_yaml_config


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    test = BatteryOTAStressTest(config)
    try:
        test.setup()
        test._ensure_login(run_index=0)
        test._navigate_to_ota_list(run_index=0)

        page = test.page

        print("\n" + "=" * 70)
        print("[1] 完整任务名是否存在于页面 HTML 中")
        print("=" * 70)
        html = page.content()
        # 今天端到端跑出的两个任务名
        for name in ["bms-v1_0_10-20261013131026", "bms-v1_0_11-20261013131106"]:
            print(f"  【{name}】在HTML中: {name in html}")
        # 看看带省略号的前缀形式
        for prefix in ["bms-v1_0_10-2026101", "bms-v1_0_11-2026101"]:
            print(f"  前缀【{prefix}】在HTML中: {prefix in html}")

        print("\n" + "=" * 70)
        print("[2] 名称列单元格结构（前5行首列）")
        print("=" * 70)
        cells = page.locator("tr td:nth-child(1)")
        print(f"  首列单元格数量: {cells.count()}")
        for i in range(min(cells.count(), 5)):
            c = cells.nth(i)
            try:
                outer = c.evaluate("e => e.outerHTML")
                print(f"\n  单元格[{i}] outerHTML:\n    {outer[:400]}")
            except Exception as e:
                print(f"  单元格[{i}] 读取失败: {e}")

        print("\n" + "=" * 70)
        print("[3] 表格行 inner_text（前4行，| 分隔）")
        print("=" * 70)
        rows = page.locator("tr")
        print(f"  <tr> 总数: {rows.count()}")
        for i in range(min(rows.count(), 4)):
            try:
                txt = (rows.nth(i).inner_text() or "").replace("\n", " | ")[:160]
                print(f"  行[{i}]: {txt}")
            except Exception as e:
                print(f"  行[{i}] 读取失败: {e}")

        print("\n" + "=" * 70)
        print("[4] 含'启动'文字的元素（标签/可见性）")
        print("=" * 70)
        btns = page.locator("text=启动").all()
        print(f"  元素数: {len(btns)}")
        for i, b in enumerate(btns[:6]):
            try:
                tag = b.evaluate("e => e.tagName")
                vis = b.is_visible()
                txt = (b.inner_text() or "")[:20]
                print(f"  [{i}] <{tag}> visible={vis} text={txt!r}")
            except Exception as e:
                print(f"  [{i}] 读取失败: {e}")

        print("\n" + "=" * 70)
        print("[5] get_by_role('row') 是否可用")
        print("=" * 70)
        try:
            r = page.get_by_role("row")
            print(f"  get_by_role('row') 数量: {r.count()}")
            r2 = page.get_by_role("row", has_text="bms-v1")
            print(f"  get_by_role('row', has_text='bms-v1') 数量: {r2.count()}")
        except Exception as e:
            print(f"  get_by_role 异常: {e}")

        print("\n探测完成（未创建/修改任何任务）")
        return 0
    except Exception as e:
        print(f"\n[探测失败] {e}")
        import traceback
        traceback.print_exc()
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
