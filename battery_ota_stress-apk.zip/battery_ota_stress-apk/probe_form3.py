#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 干跑探测：完整填写新增任务表单（含设备分组选择），但不点保存
================================================================================
 直接复用 test.py 的 _fill_task_form 做真实演练，验证所有选择器。
 不点【保存】，不产生任何数据！
 运行：python probe_form3.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest
from core.utils import load_yaml_config


def dump_page_state(page, tag):
    """打印现场控件信息，用于分组选择失败时排查。"""
    print(f"\n===== 现场分析：{tag} =====")
    print("[可见 label]")
    labels = page.locator("label:visible")
    for i in range(min(labels.count(), 30)):
        try:
            txt = labels.nth(i).inner_text(timeout=500).strip()
            if txt:
                print(f"    - {txt}")
        except Exception:
            pass
    print("[可见输入框 placeholder]")
    inputs = page.locator("input:visible")
    for i in range(min(inputs.count(), 30)):
        try:
            ph = inputs.nth(i).get_attribute("placeholder")
            if ph:
                print(f"    - {ph}")
        except Exception:
            pass
    print("[可见下拉选项/li]")
    seen = set()
    for sel in [".el-select-dropdown__item:visible", ".ant-select-item-option:visible",
                    "[role='option']:visible", "li:visible"]:
        loc = page.locator(sel)
        try:
            n = loc.count()
        except Exception:
            n = 0
        for i in range(min(n, 30)):
            try:
                txt = loc.nth(i).inner_text(timeout=500).strip()
                if txt and txt not in seen and len(txt) < 60:
                    seen.add(txt)
                    print(f"    {txt}")
            except Exception:
                pass


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    test = BatteryOTAStressTest(config)
    try:
        test.setup()
        test._ensure_login(run_index=0)
        test._navigate_to_ota_list(run_index=0)
        test._open_create_dialog(run_index=0)
        test.page.wait_for_timeout(2000)

        task_name = "probe-dryrun-" + __import__("datetime").datetime.now().strftime("%H%M%S")
        print(f"\n>>> 干跑填表（任务名: {task_name}），不点保存")
        try:
            test._fill_task_form("bms-v1.0.10", task_name, run_index=0)
            print("\n" + "=" * 70)
            print("[干跑通过] 表单全部字段填写成功（产品/固件/任务名/升级模式/升级范围/设备分组）")
            print("=" * 70)
            test.screenshot("probe3_form_filled", 0)
            return 0
        except Exception as e:
            print(f"\n[干跑失败] {e}")
            test.screenshot("probe3_fail", 0)
            dump_page_state(test.page, "填表失败现场")
            return 1
    except Exception as e:
        print(f"\n[探测异常] {e}")
        import traceback
        traceback.print_exc()
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
