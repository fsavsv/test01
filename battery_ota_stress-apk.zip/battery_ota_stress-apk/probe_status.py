#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 快速验证：读取任务列表中 bms-v1 前缀任务的当前状态（无副作用）
================================================================================
 目的：确认上一次端到端运行点击【启动】后，任务状态是否真的变为"运行中"。
 运行：python probe_status.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest
from core.utils import load_yaml_config


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    test = BatteryOTAStressTest(config)
    try:
        test.setup()
        test._ensure_login(run_index=0)
        # 直接 goto + reload，拿最新列表数据
        test.page.goto(test._ota_list_url(), wait_until="domcontentloaded")
        test.page.wait_for_timeout(3000)
        test.page.reload(wait_until="domcontentloaded")
        test.page.wait_for_timeout(3000)

        rows = test.page.locator("tr")
        print("\n任务列表（bms-v1 前缀，| 分隔列）：")
        print("-" * 70)
        for i in range(min(rows.count(), 25)):
            try:
                txt = (rows.nth(i).inner_text() or "").replace("\n", " | ")
            except Exception:
                continue
            if "bms-v1" in txt:
                print(f"  {txt[:150]}")
        print("-" * 70)
        return 0
    except Exception as e:
        print(f"\n[探测失败] {e}")
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
