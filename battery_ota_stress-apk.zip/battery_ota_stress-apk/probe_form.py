#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 表单探测脚本：登录 -> 点【新增任务】-> 分析表单结构 -> 截图
================================================================================
 只打开表单做结构分析，不填写、不保存、不产生任何数据！
 运行：python probe_form.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest
from core.utils import load_yaml_config


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    test = BatteryOTAStressTest(config)
    try:
        test.setup()
        test._ensure_login(run_index=0)

        # 进入列表页并点开新增任务表单
        test._navigate_to_ota_list(run_index=0)
        test._open_create_dialog(run_index=0)
        page = test.page
        page.wait_for_timeout(2000)
        test.screenshot("probe_form", 0)

        print("\n" + "=" * 70)
        print("表单结构分析（用于校准选择器）")
        print("=" * 70)

        # 1. 弹窗分析（Element UI / antd / 普通页面）
        for name, sel in [("el-dialog", ".el-dialog:visible"),
                          ("el-drawer", ".el-drawer:visible"),
                          ("ant-modal", ".ant-modal:visible"),
                          ("ant-drawer", ".ant-drawer:visible")]:
            cnt = page.locator(sel).count()
            if cnt > 0:
                print(f"[弹窗] 发现 {name} x {cnt}")

        # 2. 表单项 label 列表
        print("\n[表单项 label]")
        for sel in [".el-form-item__label", ".ant-form-item-label label", "label"]:
            loc = page.locator(f"{sel}:visible")
            try:
                n = loc.count()
            except Exception:
                n = 0
            if n > 0:
                print(f"  选择器 {sel} 命中 {n} 个：")
                for i in range(min(n, 20)):
                    try:
                        print(f"    - {loc.nth(i).inner_text(timeout=500).strip()}")
                    except Exception:
                        pass
                break

        # 3. 所有可见输入框 placeholder
        print("\n[输入框 placeholder]")
        inputs = page.locator("input:visible")
        for i in range(min(inputs.count(), 20)):
            try:
                ph = inputs.nth(i).get_attribute("placeholder")
                if ph:
                    print(f"    - {ph}")
            except Exception:
                pass

        # 4. 单选按钮组
        print("\n[单选/复选文字]")
        for sel in [".el-radio:visible", ".ant-radio-wrapper:visible"]:
            loc = page.locator(sel)
            try:
                n = loc.count()
            except Exception:
                n = 0
            if n > 0:
                print(f"  选择器 {sel} 命中 {n} 个：")
                for i in range(min(n, 20)):
                    try:
                        print(f"    - {loc.nth(i).inner_text(timeout=500).strip()}")
                    except Exception:
                        pass

        # 5. 按钮列表
        print("\n[按钮]")
        btns = page.locator("button:visible")
        for i in range(min(btns.count(), 20)):
            try:
                txt = btns.nth(i).inner_text(timeout=500).strip()
                if txt:
                    print(f"    - {txt}")
            except Exception:
                pass

        print("\n当前URL:", page.url)
        print("=" * 70)
        print("探测完成（未填写、未保存、无任何副作用）")
        return 0
    except Exception as e:
        print(f"\n[探测失败] {e}")
        import traceback
        traceback.print_exc()
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
