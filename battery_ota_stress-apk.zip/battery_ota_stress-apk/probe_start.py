#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
 探测脚本：观察点击【启动】后页面出现的确认弹窗 DOM 结构
================================================================================
 背景：点击启动后任务状态未变（仍"已创建"），怀疑有确认弹窗未处理。
 做法：找一个"已创建"的 bms-v1_0_10 任务行，点击其【启动】，
       然后 dump 所有疑似弹窗的 DOM + 截图，不做后续确认动作。
 运行：python probe_start.py
================================================================================
"""

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from test import BatteryOTAStressTest
from core.utils import load_yaml_config


def main():
    config = load_yaml_config(os.path.join(_SCRIPT_DIR, "config.yaml"))
    test = BatteryOTAStressTest(config)
    page = None
    try:
        test.setup()
        test._ensure_login(run_index=0)
        page = test.page
        page.goto(test._ota_list_url(), wait_until="domcontentloaded")
        page.wait_for_timeout(3000)

        # 找"已创建"且含 bms-v1_0_10 的第一行（顶部最新）
        rows = page.locator("tr")
        target_row = None
        for i in range(min(rows.count(), 25)):
            try:
                txt = rows.nth(i).inner_text() or ""
            except Exception:
                continue
            if "bms-v1_0_10-20261013" in txt and "已创建" in txt:
                target_row = rows.nth(i)
                print(f"目标行[{i}]: {txt[:120]}")
                break
        if target_row is None:
            print("未找到已创建的 bms-v1_0_10 任务行")
            return 1

        # 点击该行的【启动】span
        btn = target_row.locator("span:has-text('启动')")
        print(f"行内'启动'span数量: {btn.count()}")
        if not test._click_first_visible(btn, 3000):
            print("点击启动失败")
            return 1
        print("已点击【启动】，等待 2 秒观察页面变化...")
        page.wait_for_timeout(2000)
        test.screenshot("after_start_click", 0)

        # dump 所有疑似弹窗元素
        print("\n[疑似弹窗元素]")
        for sel in ["[class*='dialog']:visible", "[class*='modal']:visible",
                    "[class*='Message']:visible", "[class*='message']:visible",
                    "[class*='confirm']:visible", "[class*='popup']:visible",
                    "[class*='popover']:visible", "[role='dialog']:visible",
                    "[class*='notify']:visible", "[class*='toast']:visible"]:
            try:
                loc = page.locator(sel)
                if loc.count() > 0:
                    for i in range(min(loc.count(), 3)):
                        outer = loc.nth(i).evaluate("e => e.outerHTML")
                        print(f"\n  {sel} [{i}]:\n    {outer[:500]}")
            except Exception:
                continue

        # dump 当前所有可见的"确定/取消"按钮
        print("\n[可见的确定/取消按钮]")
        for txt in ["确定", "取消", "确认"]:
            try:
                loc = page.locator(f"button:has-text('{txt}'):visible, span:has-text('{txt}'):visible")
                print(f"  '{txt}': {loc.count()} 个")
            except Exception:
                pass

        print("\n探测完成（未做确认动作）")
        return 0
    except Exception as e:
        print(f"\n[探测失败] {e}")
        import traceback
        traceback.print_exc()
        return 2
    finally:
        try:
            test.teardown()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
